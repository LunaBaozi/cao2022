swiftlib_javascript
===================

This repository contains the JavaScript implementation of a dynamic programming algorithm
for the optimization of degenerate codon libraries.  Visit

http://rosettadesign.med.unc.edu/SwiftLib

for more details.
